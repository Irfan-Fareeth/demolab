# typing-game
A small project of "Typing master game" in C++ with GUI interface.
I have also included text files, which include paragraphs and words.
