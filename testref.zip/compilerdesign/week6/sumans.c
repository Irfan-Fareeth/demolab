#include<stdio.h>
int main()
{
	int sum=0;
	int i=0;
	if(i == 0) 
{sum+=i;
i++;
}
if(i == 1) 
{sum+=i;
i++;
}
if(i == 2) 
{sum+=i;
i++;
}
if(i == 3) 
{sum+=i;
i++;
}
if(i == 4) 
{sum+=i;
i++;
}
if(i == 5) 
{sum+=i;
i++;
}

	printf("%d",sum);
	return 0;
}
