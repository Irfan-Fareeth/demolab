switch (x) {
    case 1:
        y = y + 1;
        break;
    case 2:
        y = y - 2;
        break;
    default:
        y = 0;
}
