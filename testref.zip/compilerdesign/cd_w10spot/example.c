if(c==1){a=a+1;}else{a=a+2;}
