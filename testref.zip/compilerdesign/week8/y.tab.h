#define SWITCH 257
#define CASE 258
#define ALPHA 259
#define DEFAULT 260
#define BREAK 261
#define COLON 262
#define SEMICOLON 263
#define NUMBER 264
